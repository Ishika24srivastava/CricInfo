﻿using System.Collections.Generic;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public interface IclsAddPlayerDL
    {
        bool CreatePlayer(clsPlayerDetailsVO player);
        void DeletePlayer(int jerseyNo);
        List<clsPlayerDetailsVO> GetAllPlayers();
        clsPlayerDetailsVO GetPlayer(int jerseyNo);
        void UpdatePlayer(clsPlayerDetailsVO player);
    }
}