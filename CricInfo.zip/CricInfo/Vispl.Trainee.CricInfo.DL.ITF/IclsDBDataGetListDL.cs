﻿namespace Vispl.Trainee.CricInfo.DL
{
    public interface IclsDBDataGetListDL
    {
        string[] BattingView();
        string[] BowlingView();
        string[] NationalityView();
        string[] PlayerNameListView();
        string[] RoleView();
        string[] StatusView();
        string[] TeamListView();
        string[] TimeZoneView();
        string[] TypeView();
        string[] VenueView();
    }
}