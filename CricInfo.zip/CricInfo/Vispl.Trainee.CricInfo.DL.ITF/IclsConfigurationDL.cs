﻿namespace Vispl.Trainee.CricInfo.DL
{
    public interface IclsConfigurationDL
    {
        void SaveConnectionStringToJson();
    }
}