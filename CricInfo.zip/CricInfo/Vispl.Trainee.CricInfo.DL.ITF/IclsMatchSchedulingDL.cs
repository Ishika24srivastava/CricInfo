﻿using System;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public interface IclsMatchSchedulingDL
    {
        void MatchDataInsert(clsMatchSchedulingDetailsVO matchDataInsert);
        void MatchFilter(DateTimeOffset dateTimeOffset1, DateTimeOffset dateTimeOffset2, MatchSchedulingDetailListVO matchDetailsList);
        void MatchSelection(MatchSchedulingDetailListVO matchSchedule);
        void TeamSelect(clsTeamDetailsVO teamsCollection);
    }
}