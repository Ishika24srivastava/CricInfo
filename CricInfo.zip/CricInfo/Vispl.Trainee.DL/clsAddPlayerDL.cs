﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public class clsAddPlayerDL
    {
        private readonly string connectionString;

        public clsAddPlayerDL()
        {
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
        }

        public void SelectPlayer(List<clsPlayerDetailsVO> playerCollection)
        {
            playerCollection.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Id, FirstName, LastName, Nationality, Email, PhoneNumber, DateOfBirth, DebutDate, Team, BattingStyle, BowlingStyle, MatchesPlayed, RunsScored, WicketsTaken, ICCRanking, Centuries, HalfCenturies, Captain, ViceCaptain, Picture, JerseyNumber FROM PlayersAdd";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    clsPlayerDetailsVO player = new clsPlayerDetailsVO
                    {
                        Id = Convert.ToInt32(row["Id"]),
                        FirstName = row["FirstName"].ToString(),
                        LastName = row["LastName"].ToString(),
                        Nationality = row["Nationality"].ToString(),
                        Email = row["Email"].ToString(),
                        PhoneNumber = row["PhoneNumber"].ToString(),
                        DateOfBirth = Convert.ToDateTime(row["DateOfBirth"]),
                        DebutDate = Convert.ToDateTime(row["DebutDate"]),
                        Team = row["Team"].ToString(),
                        BattingStyle = row["BattingStyle"].ToString(),
                        BowlingStyle = row["BowlingStyle"].ToString(),
                        MatchesPlayed = Convert.ToInt32(row["MatchesPlayed"]),
                        RunsScored = Convert.ToInt32(row["RunsScored"]),
                        WicketsTaken = Convert.ToInt32(row["WicketsTaken"]),
                        ICCRanking = Convert.ToInt32(row["ICCRanking"]),
                        Centuries = Convert.ToInt32(row["Centuries"]),
                        HalfCenturies = Convert.ToInt32(row["HalfCenturies"]),
                        Captain = Convert.ToBoolean(row["Captain"]),
                        ViceCaptain = Convert.ToBoolean(row["ViceCaptain"]),
                        Picture = row.IsNull("Picture") ? null : (byte[])row["Picture"],
                        JerseyNumber = Convert.ToInt32(row["JerseyNumber"])
                    };

                    playerCollection.Add(player);
                }
            }
        }



        public void InsertPlayer(clsPlayerDetailsVO VO)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO PlayersAdd (FirstName, LastName, Team, Nationality, Email, PhoneNumber, DateOfBirth, BattingStyle, BowlingStyle, MatchesPlayed, RunsScored, WicketsTaken, ICCRanking, HalfCenturies, Centuries, Captain, ViceCaptain, DebutDate,  JerseyNumber,Picture) " +
                             "VALUES (@FirstName, @LastName, @Team, @Nationality, @Email, @PhoneNumber, @DateOfBirth, @BattingStyle, @BowlingStyle, @MatchesPlayed, @RunsScored, @WicketsTaken, @ICCRanking, @HalfCenturies, @Centuries, @Captain, @ViceCaptain, @DebutDate, @JerseyNumber,@Picture)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FirstName", VO.FirstName);
                command.Parameters.AddWithValue("@LastName", VO.LastName);
                command.Parameters.AddWithValue("@Team", VO.Team);
                command.Parameters.AddWithValue("@Nationality", (object)VO.Nationality ?? DBNull.Value);
                command.Parameters.AddWithValue("@Email", VO.Email);
                command.Parameters.AddWithValue("@PhoneNumber", VO.PhoneNumber);
                command.Parameters.AddWithValue("@DateOfBirth", VO.DateOfBirth);
                command.Parameters.AddWithValue("@BattingStyle", VO.BattingStyle);
                command.Parameters.AddWithValue("@BowlingStyle", VO.BowlingStyle);
                command.Parameters.AddWithValue("@MatchesPlayed", VO.MatchesPlayed);
                command.Parameters.AddWithValue("@RunsScored", VO.RunsScored);
                command.Parameters.AddWithValue("@WicketsTaken", VO.WicketsTaken);
                command.Parameters.AddWithValue("@ICCRanking", VO.ICCRanking);
                command.Parameters.AddWithValue("@HalfCenturies", VO.HalfCenturies);
                command.Parameters.AddWithValue("@Centuries", VO.Centuries);
                command.Parameters.AddWithValue("@Captain", VO.Captain);
                command.Parameters.AddWithValue("@ViceCaptain", VO.ViceCaptain);
                command.Parameters.AddWithValue("@DebutDate", VO.DebutDate);
                command.Parameters.AddWithValue("@JerseyNumber", VO.JerseyNumber);
               command.Parameters.AddWithValue("@Picture", (object)VO.Picture ?? DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
