﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public class clsDBDataGetListDL : IclsDBDataGetListDL
    {
        private readonly string connectionString;

        public clsDBDataGetListDL()

        {
            var connectionInfoDL = new clsConfigurationDL();
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
        }
        public string[] TeamListView()
        {
            List<string> teams = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT TeamName FROM TeamList";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        string Team1 = reader["TeamName"].ToString();
                        teams.Add(Team1);
                    }
                }
            }
            return teams.ToArray();
        }
        public string[] StatusView()
        {
            List<string> status = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT StatusName FROM MatchStatus";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string member = reader["StatusName"].ToString();
                        status.Add(member);
                    }
                }
            }
            return status.ToArray();
        }
        public string[] VenueView()
        {
            List<string> venues = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT VenueName FROM MatchVenue";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string venue = reader["VenueName"].ToString();
                        venues.Add(venue);
                    }
                }
            }
            return venues.ToArray();
        }
        public string[] TypeView()
        {
            List<string> types = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT MatchStyleName FROM MatchType";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string type = reader["MatchStyleName"].ToString();
                        types.Add(type);
                    }
                }
            }
            return types.ToArray();
        }

        public string[] TimeZoneView()
        {
            List<string> timezones = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT TimeZoneName FROM TimeZone";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string timezone = reader["TimeZoneName"].ToString();
                        timezones.Add(timezone);
                    }
                }
            }
            return timezones.ToArray();
        }
        public string[] NationalityView()
        {
            List<string> Nationalities = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Nationality FROM Country";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string nationality = reader["Nationality"].ToString();
                        Nationalities.Add(nationality);
                    }
                }
            }
            return Nationalities.ToArray();
        }
        public string[] BowlingView()
        {
            List<string> BowlingStyles = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT StyleName FROM BowlingStyle";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string bowlingStyle = reader["StyleName"].ToString();
                        BowlingStyles.Add(bowlingStyle);
                    }
                }
            }
            return BowlingStyles.ToArray();
        }
        public string[] BattingView()
        {
            List<string> BattingStyles = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT StyleName FROM BattingStyle";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string battingStyle = reader["StyleName"].ToString();
                        BattingStyles.Add(battingStyle);
                    }
                }
            }
            return BattingStyles.ToArray();
        }
        public string[] RoleView()
        {
            List<string> Roles = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Role FROM PlayerRole";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string role = reader["Role"].ToString();
                        Roles.Add(role);
                    }
                }
            }
            return Roles.ToArray();
        }
        public string[] PlayerNameListView()
        {
            List<string> Players = new List<string>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT FirstName, LastName FROM PlayerList";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string firstName = reader["FirstName"].ToString();
                        string lastName = reader["LastName"].ToString();
                        Players.Add(firstName + " " + lastName);
                    }
                }
            }
            return Players.ToArray();
        }
        public static TimeSpan ParseTimeZoneOffset(string timeZoneString)
        {
            // Check for the presence of '+' or '-' and split accordingly
            bool isPositive = timeZoneString.Contains('+');
            char[] delimiter = isPositive ? new char[] { '+' } : new char[] { '-' };

            string[] parts = timeZoneString.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);

            // Parse hours and minutes
            int hours = int.Parse(parts[1].Substring(0, 2));
            int minutes = int.Parse(parts[1].Substring(2, 2));

            // Determine the sign based on the presence of '+' or '-'
            int sign = isPositive ? 1 : -1;

            // Return the computed TimeSpan
            return new TimeSpan(sign * hours, sign * minutes, 0);
        }
       

    }
}
