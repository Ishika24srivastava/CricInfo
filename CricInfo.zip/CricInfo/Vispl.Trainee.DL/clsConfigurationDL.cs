﻿using System;
using System.IO;
using Newtonsoft.Json;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public class clsConfigurationDL : IclsConfigurationDL
    {
        private static string JsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "connectionDetails.json");

        public void SaveConnectionStringToJson()
        {
            var connectionInfo = new clsConfigurationVO
            {
                ServerName = "DESKTOP-L8C9MNU",
                DatabaseName = "Cricket",
                IntegratedSecurity = true
            };

            var connectionStrings = new
            {
                ConnectionStrings = new
                {
                    Server = connectionInfo.ServerName,
                    Database = connectionInfo.DatabaseName,
                    IntegratedSecurity = connectionInfo.IntegratedSecurity.ToString()
                }
            };

            string json = JsonConvert.SerializeObject(connectionStrings, Formatting.Indented);
            File.WriteAllText(JsonFilePath, json);
        }

        public static string GetConnectionStringFromJson()
        {
            if (!File.Exists(JsonFilePath))
            {
                throw new FileNotFoundException("The connection string JSON file does not exist.");
            }

            string json = File.ReadAllText(JsonFilePath);
            dynamic connectionStrings = JsonConvert.DeserializeObject(json);

            string server = connectionStrings.ConnectionStrings.Server;
            string database = connectionStrings.ConnectionStrings.Database;
            string integratedSecurity = connectionStrings.ConnectionStrings.IntegratedSecurity;

            return $"Server={server};Database={database};Integrated Security={integratedSecurity};";
        }
    }
}
