﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.DL;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public class clsMatchSchedulingDL
    {
        private readonly string connectionString;

        public clsMatchSchedulingDL()

        {
            var connectionInfoDL = new clsConfigurationDL();
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
        }
        public void MatchSelection(List<clsMatchSchedulingDetailsVO> matchSchedule)
        {
          
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT MatchId, MatchVenue, MatchType, MatchStatus, Team1, Team2,DateTimeTimezone FROM MatchSchedulingDetails";

                SqlCommand command = new SqlCommand(query, connection);

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dataTable = new DataTable();

                connection.Open();
                adapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    DateTimeOffset dateTimeOffset = (DateTimeOffset)row["DateTimeTimezone"];
                    TimeSpan temptimezone = dateTimeOffset.Offset;
                    string sign = temptimezone >= TimeSpan.Zero ? "+" : "-";
                    string timezone = "UTC" + sign + temptimezone.ToString(@"hh\:mm");
                    matchSchedule.Add(new clsMatchSchedulingDetailsVO
                    {
                        MatchId = (int)row["MatchId"],
                        MatchVenue = (string)row["MatchVenue"],
                        MatchType = (string)row["MatchType"],
                        MatchStatus = (string)row["MatchStatus"],
                        Team1 = (string)row["Team1"],
                        Team2 = (string)row["Team2"],
                        MatchDate = dateTimeOffset.DateTime,
                        TimeZone = timezone
                    }) ;
                }
            }
        }

        public void MatchDataInsert(clsMatchSchedulingDetailsVO matchDataInsert)
        {
            TimeSpan timeZoneOffset = ParseTimeZoneOffset(matchDataInsert.TimeZone);
            DateTimeOffset dateTimeOffset = new DateTimeOffset(matchDataInsert.MatchDate, timeZoneOffset);
            try
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO MatchSchedulingDetails (DateTimeTimezone, MatchVenue, MatchType, MatchStatus, Team1, Team2) " +
                                   "VALUES (@DateTimeTimeZone,@MatchVenue, @MatchType, @MatchStatus, @Team1, @Team2)";

                    SqlCommand command = new SqlCommand(query, connection);
                    
                    command.Parameters.AddWithValue("@DateTimeTimeZone",dateTimeOffset);
                    command.Parameters.AddWithValue("@MatchVenue", matchDataInsert.MatchVenue);
                    command.Parameters.AddWithValue("@MatchType", matchDataInsert.MatchType);
                    command.Parameters.AddWithValue("@MatchStatus", matchDataInsert.MatchStatus);
                    command.Parameters.AddWithValue("@Team1", matchDataInsert.Team1);
                    command.Parameters.AddWithValue("@Team2", matchDataInsert.Team2);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    Console.WriteLine("{0} rows affected.", rowsAffected);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        public void InsertTeam(clsTeamDetailsVO teamDetails)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO TeamDetails (TeamName, TeamShortName, CaptainName, ViceCaptainName,TeamLogo) VALUES (@TeamName, @TeamShortName, @CaptainName, @ViceCaptainName,@TeamLogo)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TeamName", teamDetails.TeamName);
                command.Parameters.AddWithValue("@TeamShortName", teamDetails.TeamShortName);
                command.Parameters.AddWithValue("@CaptainName", teamDetails.CaptainName);
                command.Parameters.AddWithValue("@ViceCaptainName", teamDetails.ViceCaptainName);
                command.Parameters.AddWithValue("@TeamLogo", (object)teamDetails.TeamLogo ?? DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void TeamSelect(List<clsTeamDetailsVO> teamsCollection)
        {


            teamsCollection.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT TeamId, TeamName, TeamShortName, CaptainName, ViceCaptainName,TeamLogo FROM TeamDetails";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();

                connection.Open();
                adapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    teamsCollection.Add(new clsTeamDetailsVO
                    {
                        TeamId = (int)row["TeamId"],
                        TeamName = (string)row["TeamName"],
                        TeamShortName = (string)row["TeamShortName"],
                        CaptainName = (string)row["CaptainName"],
                        ViceCaptainName = (string)row["ViceCaptainName"],
                        TeamLogo = Convert.IsDBNull(row["TeamLogo"]) ? null : (byte[])row["TeamLogo"]


                    });
                }
            }
        }




        static TimeSpan ParseTimeZoneOffset(string timeZoneString)
        {

            string[] parts = timeZoneString.Split('+', '-');
            int hours = int.Parse(parts[1].Substring(0, 2)); // Extract hours
            int minutes = int.Parse(parts[1].Substring(3, 2)); // Extract minutes

            // Determine the sign of the offset
            int sign = (timeZoneString[3] == '+') ? 1 : -1;

            // Create a TimeSpan representing the time zone offset
            return TimeSpan.FromHours(sign * hours) + TimeSpan.FromMinutes(sign * minutes);
        }

        public List<clsMatchSchedulingDetailsVO> FilterMatchesByDateTimeAndTimeZone(List<clsMatchSchedulingDetailsVO> matches, DateTime startDateString, DateTime endDateString, string timeZone1, string timeZone2)
        {
            List<clsMatchSchedulingDetailsVO> matchDetailsList = new List<clsMatchSchedulingDetailsVO>();
            TimeSpan timeZoneOffset1 = ParseTimeZoneOffset(timeZone1);
            DateTimeOffset dateTimeOffset1 = new DateTimeOffset(startDateString, timeZoneOffset1);

            TimeSpan timeZoneOffset2 = ParseTimeZoneOffset(timeZone2);
            DateTimeOffset dateTimeOffset2 = new DateTimeOffset(endDateString, timeZoneOffset2);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT MatchId, MatchVenue, MatchType, MatchStatus, Team1, Team2, DateTimeTimezone FROM MatchSchedulingDetails WHERE DateTimeTimezone > @StartDateTimeOffset AND DateTimeTimezone < @EndDateTimeOffset;";


                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.Add("@StartDateTimeOffset", dateTimeOffset1);
                command.Parameters.Add("@EndDateTimeOffset", dateTimeOffset1);
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                DataTable dataTable = new DataTable();

                connection.Open();
                adapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    DateTimeOffset dateTimeOffset = (DateTimeOffset)row["DateTimeTimezone"];
                    TimeSpan temptimezone = dateTimeOffset.Offset;
                    string sign = temptimezone >= TimeSpan.Zero ? "+" : "-";
                    string timezone = "UTC" + sign + temptimezone.ToString(@"hh\:mm");
                    matchDetailsList.Add(new clsMatchSchedulingDetailsVO
                    {
                        MatchId = (int)row["MatchId"],
                        MatchVenue = (string)row["MatchVenue"],
                        MatchType = (string)row["MatchType"],
                        MatchStatus = (string)row["MatchStatus"],
                        Team1 = (string)row["Team1"],
                        Team2 = (string)row["Team2"],
                        MatchDate = dateTimeOffset.DateTime,
                        TimeZone = timezone
                    });
                }
            }

            return matchDetailsList;
        }
    }
}
