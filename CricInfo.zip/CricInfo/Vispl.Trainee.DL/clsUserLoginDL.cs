﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.DL
{
    public class clsUserLoginDL 
    {
        private readonly string connectionString;

        public clsUserLoginDL()
        {
            var configurationDL = new clsConfigurationDL();
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
        }
        public bool GetAuthenticatedUser(clsUserLoginVO cls_User)
        {
          
           
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string sqlQuery = "SELECT * FROM LoginUser  WHERE UserType = @UserType";
                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@UserType", cls_User.UserType);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    bool validUser = false;
                    while (reader.Read())
                    {
                        if (reader.HasRows)
                        {
                            string user = reader[1].ToString();
                            if (user.ToLower() == cls_User.UserName.ToLower())
                            {
                                string storedPassword = reader[2].ToString();
                                if (storedPassword == cls_User.Password)
                                {
                                    validUser = true;
                                }
                            }
                        }
                    }
                    reader.Close();
                    connection.Dispose();
                    connection.Close();
                    return validUser;
                }
            }
            catch
            {
                return false;
            }
        }

    }
}
