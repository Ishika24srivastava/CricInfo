﻿using System;
using Vispl.Trainee.CricInfo.DL;

namespace Vispl.Trainee.CricInfo.BM
{
    public interface IclsDBDataGridListBM
    {
        clsDBDataGetListDL dbData { get; set; }

        string[] GetPlayerListView();
        string[] GetStatusView();
        string[] GetTeamView();
        TimeSpan GetTimeZoneOffset(string timeZoneString);
        string[] GetTimezoneView();
        string[] GetTypeView();
        string[] GetVenueView();
    }
}