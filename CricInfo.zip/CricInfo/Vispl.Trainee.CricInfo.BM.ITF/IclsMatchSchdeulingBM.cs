﻿using System;
using Vispl.Trainee.CricInfo.DL;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.BM
{
    public interface IclsMatchSchdeulingBM
    {
        clsMatchSchedulingDetailsVO matchInsert { get; set; }
        MatchSchedulingDetailListVO matchList { get; set; }
        clsMatchSchedulingDL matchScheduling { get; set; }
        clsTeamDetailsVO teamList { get; set; }

        void MatchFilter(DateTimeOffset First, DateTimeOffset Second);
        void MatchInsert(clsMatchSchedulingDetailsVO matchInsert);
        void MatchScheduled();
        void TeamData();
    }
}