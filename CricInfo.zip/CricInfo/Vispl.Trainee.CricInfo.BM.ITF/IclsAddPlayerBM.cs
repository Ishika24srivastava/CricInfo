﻿using System.Collections.Generic;
using Vispl.Trainee.CricInfo.DL;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.BM
{
    public interface IclsAddPlayerBM
    {
        clsAddPlayerDL clsAddPlayer { get; set; }
        clsPlayerDetailsVO clsPlayerDetails { get; set; }

        bool ActuallySave(clsPlayerDetailsVO playerDetails);
        List<clsPlayerDetailsVO> AllPlayerDetails();
    }
}