﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.VO;
using Vispl.Trainee.CricInfo.DL;
using System.Web.UI.WebControls;

namespace Vispl.Trainee.CricInfo.BM
{

    public class clsAddPlayerBM
    {

        public clsAddPlayerDL addPlayer { get; set; }


        public clsPlayerDetailsVO addplayervo { get; set; }

        public clsAddPlayerBM()
            {
            addPlayer = new clsAddPlayerDL();
            }

        public void PlayerAdd(clsPlayerDetailsVO vo)
        {
            addPlayer.InsertPlayer(vo);
        }

        public List<clsPlayerDetailsVO> GetPlayers()
        {
            List<clsPlayerDetailsVO> players = new List<clsPlayerDetailsVO>();
            addPlayer.SelectPlayer(players);
            return players;
        }
    }
}
