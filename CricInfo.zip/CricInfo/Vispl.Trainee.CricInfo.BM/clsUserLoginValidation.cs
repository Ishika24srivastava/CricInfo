﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Security;
using Vispl.Trainee.CricInfo.DL;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.BM
{
    public class clsUserLoginValidation
    {
        public clsUserLoginDL clsUser { get; set; }
        public clsUserLoginVO voUser { get; set; }

        public bool UserAuthentication()
        {
            clsUser = new clsUserLoginDL();
            if (clsUser.GetAuthenticatedUser(voUser))
            {
                return true;
            }
            else { return false; }
        }
    }
}
