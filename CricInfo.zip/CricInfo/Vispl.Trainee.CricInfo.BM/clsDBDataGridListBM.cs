﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.DL;

namespace Vispl.Trainee.CricInfo.BM
{
    public class clsDBDataGridListBM 
    {
        private readonly string connectionString;
        public clsDBDataGetListDL dbData { get; set; }
        public clsDBDataGridListBM()

        {
            var connectionInfoDL = new clsConfigurationDL();
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
            dbData = new clsDBDataGetListDL();
        }


        public string[] GetTeamView()
        {
            return dbData.TeamListView();
        }
        public string[] GetStatusView()
        {
            return dbData.StatusView();
        }
        public string[] GetVenueView()
        {
            return dbData.VenueView();
        }

        public string[] GetNationalityView()
        {
            return dbData.NationalityView();
        }
        public string[] GetTypeView()
        {
            return dbData.TypeView();
        }
        public string[] GetTimezoneView()
        {
            return dbData.TimeZoneView();
        }
        public string[] GetPlayerListView()
        {
            return dbData.PlayerNameListView();
        }
        public string[] GetBowlingView()
        {
            return dbData.BowlingView();
        }

        public string[] GetBattingView()
        {
            return dbData.BattingView();
        }
        public TimeSpan GetTimeZone (string timeZoneString )
        {
            return ParseTimeZoneOffset(timeZoneString);
        }

        public static TimeSpan ParseTimeZoneOffset(string timeZoneString)
        {
            bool isPositive = timeZoneString.Contains('+');
            char[] delimiter = isPositive ? new char[] { '+' } : new char[] { '-' };
            string[] parts = timeZoneString.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
            int hours = int.Parse(parts[1].Substring(0, 2));
            int minutes = int.Parse(parts[1].Substring(2, 2));
            int sign = isPositive ? 1 : -1;
            return new TimeSpan(sign * hours, sign * minutes, 0);
        }

    }
}
