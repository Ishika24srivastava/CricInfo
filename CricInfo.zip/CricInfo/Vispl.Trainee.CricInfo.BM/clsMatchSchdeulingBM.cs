﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Vispl.Trainee.CricInfo.DL;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.BM
{

    public class clsMatchSchdeulingBM

    {
        private readonly string connectionString;

        public clsMatchSchedulingDL matchScheduling { get; set; }
        public MatchSchedulingDetailListVO matchList1 { get; set; }

        public List<clsMatchSchedulingDL> matchList { get; set; }

        public clsMatchSchedulingDetailsVO matchInsert { get; set; }

        public clsMatchSchdeulingBM()


        {
            var connectionInfoDL = new clsConfigurationDL();
            connectionString = clsConfigurationDL.GetConnectionStringFromJson();
            matchScheduling = new clsMatchSchedulingDL();

        }

        public List<clsMatchSchedulingDetailsVO> MatchScheduled()

        {
            List<clsMatchSchedulingDetailsVO> matchScheduled = new List<clsMatchSchedulingDetailsVO>();
            matchScheduling.MatchSelection(matchScheduled);
            return matchScheduled;
        }


        //public void MatchScheduled()
        //{

        //    matchScheduling.MatchSelection(matchList1);
        //}

        public void MatchInsert(clsMatchSchedulingDetailsVO matchInsert)

        {
            matchScheduling.MatchDataInsert(matchInsert);
        }
        public void TeamInsert(clsTeamDetailsVO vo)

        {
            matchScheduling.InsertTeam(vo);

        }
       


        public List<clsTeamDetailsVO> TeamSelect()

        {
            List<clsTeamDetailsVO> players = new List<clsTeamDetailsVO>();
            matchScheduling.TeamSelect(players);
            return players;
        }
        public List<clsMatchSchedulingDetailsVO> GetFilteredMatches(DateTime First, DateTime Second, string FirstTimeZone, string SecondTimeZone)
        {
            // Assuming the matches list is fetched from some data source
            List<clsMatchSchedulingDetailsVO> matches = new List<clsMatchSchedulingDetailsVO>();
            matchScheduling.FilterMatchesByDateTimeAndTimeZone(matches, First, Second, FirstTimeZone, SecondTimeZone);



            return matches;
        }






           
        }
 }