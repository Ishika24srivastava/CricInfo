﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Vispl.Trainee.CricInfo.VO

{
    public class clsPlayerDetailsVO
    {
        public int Id { get; set; }

        [Required]
        public int JerseyNumber { get; set; }

        [Required]
        public int ICCRanking { get; set; }

        [Required]
        public int Centuries { get; set; }

        [Required]
        public int HalfCenturies { get; set; }

       

        [Required]
        public DateTime DebutDate { get; set; }

        [Required]
        public bool Captain { get; set; }

        [Required]
        public bool ViceCaptain { get; set; }

        [Required]
        
        public string FirstName { get; set; }

        [Required]
       
        public string LastName { get; set; }

    

        [Required]
      
        public string Team { get; set; }

        [Required]
       
        public string Nationality { get; set; }

        [Required]
      
        public string Role { get; set; }

        [Required]
        
        public string Email { get; set; }

        [Required]
        
        public string PhoneNumber { get; set; }

        [Required]
      
        public DateTime DateOfBirth { get; set; }

        [Required]
    
        public string BattingStyle { get; set; }

        [Required]
        
        public string BowlingStyle { get; set; }

        [Required]
        public int MatchesPlayed { get; set; }

        [Required]
        public int RunsScored { get; set; }

        [Required]
        public int WicketsTaken { get; set; }

        public byte[] Picture { get; set; }
    }
}