﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vispl.Trainee.CricInfo.VO
{
    public class clsConfigurationVO
    {
        public  string ServerName{get; set;}
        public string DatabaseName { get; set;}
        public bool IntegratedSecurity { get; set;}
        public string ConnectionString { get; set;}

        public string GetConnectionString()
        {
           
            return ConnectionString;
        }
    }
}
