﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vispl.Trainee.CricInfo.VO
{
    public class MatchSchedulingDetailListVO : IEnumerable<clsMatchSchedulingDetailsVO>
    {
        private List<clsMatchSchedulingDetailsVO> matches = new List<clsMatchSchedulingDetailsVO>();

        public void Add(clsMatchSchedulingDetailsVO match)
        {
            matches.Add(match);
        }
        public void Clear()
        {
            matches.Clear();
        }

        public IEnumerator<clsMatchSchedulingDetailsVO> GetEnumerator()
        {
            return matches.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
