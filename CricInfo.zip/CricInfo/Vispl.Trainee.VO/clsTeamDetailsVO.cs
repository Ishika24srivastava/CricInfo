﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace Vispl.Trainee.CricInfo.VO
{
    public class clsTeamDetailsVO
    {
        [Key]
        public int TeamId { get; set; }
        [Required]
        [DisplayName("Team Name")]
        public String TeamName { get; set; }
        [Required]
        public string TeamShortName { get; set; }
        [Required]
        public string CaptainName { get; set; }
        [Required]
        public string ViceCaptainName { get; set; }
        public byte[] TeamLogo { get; set; }
        public string[] Players { get; set; }

        public List<clsPlayerDetailsVO> AllPlayers;

    }
}
