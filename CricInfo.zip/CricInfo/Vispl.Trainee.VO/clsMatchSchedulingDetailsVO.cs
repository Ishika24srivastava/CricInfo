﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Vispl.Trainee.CricInfo.VO
{
    public class clsMatchSchedulingDetailsVO
    {
        [Key]
        public int MatchId { get; set; }
        [Required(ErrorMessage = "Match Date is required")]
        public DateTime MatchDate { get; set; }
        [Required]
        public string MatchVenue { get; set; }
        [Required]
        public string MatchType { get; set; }
        [Required]
        public string MatchStatus { get; set; }
        [Required]
        public string Team1 { get; set; }
        [Required]
        public string Team2 { get; set; }
        public string MatchResult { get; set; }
        public string TimeZone { get; set; }
    }
}
