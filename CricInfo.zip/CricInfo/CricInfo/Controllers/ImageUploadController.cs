﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.Mvc;

namespace CricInfo.Controllers
{
    public class ImageUploadController : Controller
    {
        // GET: ImageUpload
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Save(IEnumerable<HttpPostedFileBase> Uploader)
        {
            // Ensure the directory exists
            var uploadDir = Server.MapPath("~/App_Data");
            if (!Directory.Exists(uploadDir))
            {
                Directory.CreateDirectory(uploadDir);
            }

            foreach (var file in Uploader)
            {
                if (file != null && file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine(uploadDir, fileName);
                    file.SaveAs(filePath);
                }
            }
            return Json(new { message = "File(s) uploaded successfully" });
        }

        [HttpPost]
        public ActionResult Remove(string[] fileNames)
        {
            var uploadDir = Server.MapPath("~/App_Data");

            foreach (var fileName in fileNames)
            {
                var filePath = Path.Combine(uploadDir, fileName);
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }
            }
            return Json(new { message = "File(s) removed successfully" });
        }

        public ActionResult UplaodImageBrwoser()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadImageCheck(IEnumerable<HttpPostedFileBase> UploadFiles)
        {
            byte[] bytes = null;
            if (UploadFiles != null)
            {
                foreach (var file in UploadFiles)
                {
                    if (file != null && file.ContentLength > 0)
                    {
                        using (var binaryReader = new BinaryReader(file.InputStream))
                        {
                            bytes = binaryReader.ReadBytes(file.ContentLength);
                        }
                    }
                }
            }

            string image = bytes != null ? Convert.ToBase64String(bytes) : null;

            // Clear the bytes array
            if (bytes != null)
            {
                Array.Clear(bytes, 0, bytes.Length);
                bytes = null;
            }

            return Content("<img src='data:image/png;base64," + image + "' alt='Photo' height='250' />");
        }
    }
}

