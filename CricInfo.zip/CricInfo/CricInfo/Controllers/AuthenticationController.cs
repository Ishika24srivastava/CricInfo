﻿using System.Web.Mvc;
using System.Web.Security;
using Vispl.Trainee.CricInfo.BM;
using Vispl.Trainee.CricInfo.VO;

namespace Vispl.Trainee.CricInfo.Controllers
{
    public class AuthenticationController : Controller
    {
       
        public clsUserLoginValidation userLogin { get; set; }
        public clsUserLoginVO   userLoginVo;

        public ActionResult Login()
        {
            ViewBag.Message = "Your application Login page.";
            return View();
        }
        [HttpPost]
        public ActionResult Login(int userType, string userName, string password)
        {
            userLoginVo = new clsUserLoginVO
            {
                UserName = userName,
                Password = password,
                UserType = userType
            };

            userLogin =new clsUserLoginValidation();
           userLogin.voUser= userLoginVo;
           
            if (userLogin.UserAuthentication())
            {
                FormsAuthentication.SetAuthCookie(userName, false);
                return RedirectToAction("AdminDashboard", "Home");
            }
            else
            {
                ViewBag.IsLogin = false;
                return View();
            }
        }
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("UserDashboard", "Home");
        }
    }
}
