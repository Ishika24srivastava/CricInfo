﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vispl.Trainee.CricInfo.BM;
using Vispl.Trainee.CricInfo.VO;

namespace CricInfo.Controllers
{
    public class MatchSchedulingController : Controller
    {
        // GET: MatchScheduling
        public ActionResult Index()
        {
            clsMatchSchdeulingBM  clsMatchSchdeulingBM = new clsMatchSchdeulingBM();
            //clsMatchSchdeulingBM.MatchScheduled();
            //return View();
            List<clsMatchSchedulingDetailsVO> players = clsMatchSchdeulingBM.MatchScheduled();
    
            return View(players);
        }

        public ActionResult MatchRegister()
        {
            clsDBDataGridListBM cls = new clsDBDataGridListBM();
            ViewBag.Teams = cls.GetTeamView();
            ViewBag.Status = cls.GetStatusView();
            ViewBag.Venues = cls.GetVenueView();
            ViewBag.Types = cls.GetTypeView();
            ViewBag.Timezones = cls.GetTimezoneView();
            return View();
        }

        [HttpPost]
        public ActionResult MatchRegister(clsMatchSchedulingDetailsVO model)
        {
            if (ModelState.IsValid)
            {
                clsMatchSchdeulingBM match = new clsMatchSchdeulingBM();
                match.MatchInsert(model); // Assuming MatchInsert takes a parameter for the match details
                return RedirectToAction("Index");
            }

            clsDBDataGridListBM cls = new clsDBDataGridListBM();
            ViewBag.Teams = cls.GetTeamView();
            ViewBag.Status = cls.GetStatusView();
            ViewBag.Venues = cls.GetVenueView();
            ViewBag.Types = cls.GetTypeView();
            ViewBag.Timezones = cls.GetTimezoneView();
            return View(model); // Pass the model back to the view in case of validation errors
        }

        public ActionResult MatchSchedulingFilteeration()
        {
            clsDBDataGridListBM bm = new clsDBDataGridListBM();

            ViewBag.Timezones = bm.GetTimezoneView();
            return View();
        }

        [HttpPost]
       public ActionResult MatchSchedulingFilteeration(DateTime First, DateTime Second, string FirstTimeZone, string SecondTimeZone)
        {
            clsMatchSchdeulingBM bM = new clsMatchSchdeulingBM();
            clsDBDataGridListBM bm=new clsDBDataGridListBM();
            List<clsMatchSchedulingDetailsVO> match = bM.GetFilteredMatches(First, Second, FirstTimeZone, SecondTimeZone);
            ViewBag.Timezones = bm.GetTimezoneView();
            ViewBag.GridVisible = true;
            return View(match);
        }


    public TimeSpan ParseTimeZoneOffset(string timeZoneString)
        {

            string[] parts = timeZoneString.Split('+', '-');
            int hours = int.Parse(parts[1].Substring(0, 2)); // Extract hours
            int minutes = int.Parse(parts[1].Substring(3, 2)); // Extract minutes

            // Determine the sign of the offset
            int sign = (timeZoneString[3] == '+') ? 1 : -1;

            // Create a TimeSpan representing the time zone offset
            return TimeSpan.FromHours(sign * hours) + TimeSpan.FromMinutes(sign * minutes);
        }

    }
}