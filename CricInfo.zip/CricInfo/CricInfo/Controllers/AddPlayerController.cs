﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vispl.Trainee.CricInfo.VO;
using Vispl.Trainee.CricInfo.BM;
using System.IO;

namespace CricInfo.Controllers
{
    public class AddPlayerController : Controller
    {
        private readonly clsAddPlayerBM _clsPLayerDetailsBM;
        private readonly clsDBDataGridListBM dbData;

        // Constructor to initialize the business model8
        public AddPlayerController()
        {
            _clsPLayerDetailsBM = new clsAddPlayerBM();
            dbData = new clsDBDataGridListBM();
        }

        public ActionResult Index()
        {
            List<clsPlayerDetailsVO> players = _clsPLayerDetailsBM.GetPlayers();
            // Process the player data as needed (e.g., pass it to a view).
            return View(players);
        }


        public ActionResult Create()
        {
            //var playerDetails = new clsPlayerDetailsVO();
            ViewBag.Nationality=dbData.GetNationalityView();
            ViewBag.Teams = dbData.GetTeamView();
            ViewBag.BowlingStyle = dbData.GetBowlingView();
            ViewBag.BattingStyle= dbData.GetBattingView();
            ViewBag.Role=dbData.GetTypeView();
          
            return View();
        }

        [HttpPost]
        public ActionResult Create(clsPlayerDetailsVO model, IEnumerable<HttpPostedFileBase> pictureUpload)
        {
            if (pictureUpload != null)
            {
                foreach (var file in pictureUpload)
                {
                    if (file != null && file.ContentLength > 0)
                    {
                        using (var binaryReader = new BinaryReader(file.InputStream))
                        {
                            model.Picture = binaryReader.ReadBytes(file.ContentLength);
                        }
                    }
                }
            }

           // if (ModelState.IsValid)
            {
                clsAddPlayerBM modelBM = new clsAddPlayerBM();
                modelBM.PlayerAdd(model);
                return RedirectToAction("Index");
            }

            clsDBDataGridListBM dbData = new clsDBDataGridListBM();
            ViewBag.Nationality = dbData.GetNationalityView();
            ViewBag.Teams = dbData.GetTeamView();
            ViewBag.BowlingStyle = dbData.GetBowlingView();
            ViewBag.BattingStyle = dbData.GetBattingView();
            ViewBag.Role = dbData.GetTypeView();
            return View(model);
        }


    }
}
