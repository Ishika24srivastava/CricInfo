﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vispl.Trainee.CricInfo.BM;
using Vispl.Trainee.CricInfo.VO;

namespace CricInfo.Controllers
{
    public class TeamsController : Controller
    {
        // GET: Teams
        public ActionResult Index()
        {
            clsMatchSchdeulingBM bm= new clsMatchSchdeulingBM();
            
            List<clsTeamDetailsVO> players = bm.TeamSelect();
            
            return View(players);
        }

        public ActionResult CreateTeam()
        {
            clsDBDataGridListBM clsDBDataGridListBM = new clsDBDataGridListBM();
            ViewBag.player = clsDBDataGridListBM.GetPlayerListView();
            return View();

        }

        [HttpPost]
        public ActionResult CreateTeam(clsTeamDetailsVO team, IEnumerable<HttpPostedFileBase> pictureUpload)
        {
            clsDBDataGridListBM clsDBDataGridListBM = new clsDBDataGridListBM();
            clsMatchSchdeulingBM bm = new clsMatchSchdeulingBM();
            ViewBag.player = clsDBDataGridListBM.GetPlayerListView();
            if (pictureUpload != null)
            {
                foreach (var file in pictureUpload)
                {
                    if (file != null && file.ContentLength > 0)
                    {
                        using (var binaryReader = new BinaryReader(file.InputStream))
                        {
                            team.TeamLogo = binaryReader.ReadBytes(file.ContentLength);
                        }
                    }
                }
            }
            if (ModelState.IsValid)
            {
                bm.TeamInsert(team);
                return RedirectToAction("Index");

            }
            else
            {
                return View(team);
            }


        }
       
        //[HttpPost]
        //public ActionResult Register(Cls_VO_TeamCreation cls_VO_Team)
        //{
        //    Cls_BM bM = HttpContext.Application["BM"] as Cls_BM;
        //    ViewBag.Players = bM.GetPlayersNameList();
        //    if (ModelState.IsValid)
        //    {
        //        return View();
        //    }
        //    else
        //        return View(cls_VO_Team);
        //}
    }
}